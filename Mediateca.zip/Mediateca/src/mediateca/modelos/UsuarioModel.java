/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca.modelos;

/**
 *
 * @author HP
 */
public class UsuarioModel {
    int id;
    int rol_id;
    String correo;
    String nombre;
    String apellido;
    String password;

  

    public UsuarioModel() {
    }


    public UsuarioModel(int id, int rol_id, String correo, String nombre, String apellido, String password) {
        this.id = id;
        this.rol_id = rol_id;
        this.correo = correo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRol_id() {
        return rol_id;
    }

    public void setRol_id(int rol_id) {
        this.rol_id = rol_id;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "UsuarioModel{" + "id=" + id + ", rol_id=" + rol_id + ", correo=" + correo + ", nombre=" + nombre + ", apellido=" + apellido + ", password=" + password + '}';
    }
    
}
