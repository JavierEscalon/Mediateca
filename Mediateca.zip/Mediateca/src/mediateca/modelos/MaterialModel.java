/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca.modelos;

/**
 *
 * @author HP
 */
public class MaterialModel {

    String codigoIdentificacionInterna;
    String titulo;
    boolean estado;
    int usuarioId;
    String editorial;
    int unidadesDisponibles;
    int numeroDePaginas;
    String isbn;
    String autor;
    int anioPublicacion;
    String fechaPublicacion;
    String periodicidad;
    String genero;
    String duracion;
    String artista;
    int numeroCanciones;
    String director;
    String tipo;

    public MaterialModel() {
    }

    public MaterialModel(String codigoIdentificacionInterna, String titulo, boolean estado, int usuarioId, String editorial, int unidadesDisponibles, int numeroDePaginas, String isbn, String autor, int anioPublicacion, String fechaPublicacion, String periodicidad, String genero, String duracion, String artista, int numeroCanciones, String director, String tipo) {
        this.codigoIdentificacionInterna = codigoIdentificacionInterna;
        this.titulo = titulo;
        this.estado = estado;
        this.usuarioId = usuarioId;
        this.editorial = editorial;
        this.unidadesDisponibles = unidadesDisponibles;
        this.numeroDePaginas = numeroDePaginas;
        this.isbn = isbn;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.fechaPublicacion = fechaPublicacion;
        this.periodicidad = periodicidad;
        this.genero = genero;
        this.duracion = duracion;
        this.artista = artista;
        this.numeroCanciones = numeroCanciones;
        this.director = director;
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
      
    public String getCodigoIdentificacionInterna() {
        return codigoIdentificacionInterna;
    }

    public void setCodigoIdentificacionInterna(String codigoIdentificacionInterna) {
        this.codigoIdentificacionInterna = codigoIdentificacionInterna;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getUnidadesDisponibles() {
        return unidadesDisponibles;
    }

    public void setUnidadesDisponibles(int unidadesDisponibles) {
        this.unidadesDisponibles = unidadesDisponibles;
    }

    public int getNumeroDePaginas() {
        return numeroDePaginas;
    }

    public void setNumeroDePaginas(int numeroDePaginas) {
        this.numeroDePaginas = numeroDePaginas;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public String getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(String fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public String getPeriodicidad() {
        return periodicidad;
    }

    public void setPeriodicidad(String periodicidad) {
        this.periodicidad = periodicidad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public int getNumeroCanciones() {
        return numeroCanciones;
    }

    public void setNumeroCanciones(int numeroCanciones) {
        this.numeroCanciones = numeroCanciones;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }
    
}
