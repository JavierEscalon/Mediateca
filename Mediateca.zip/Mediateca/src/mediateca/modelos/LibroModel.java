/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca.modelos;

/**
 *
 * @author HP
 */
public class LibroModel {
    String codigoIdentificacionInterna;
    String titulo;
    boolean estado;
    int usuarioId;
    String editorial;
    int unidadesDisponibles;
    int numeroDePaginas;
    String isbn;
    String autor;
    int anioPublicacion;

    public LibroModel(String codigoIdentificacionInterna, String titulo, boolean estado, int usuarioId, String editorial, int unidadesDisponibles, int numeroDePaginas, String isbn, String autor, int anioPublicacion) {
        this.codigoIdentificacionInterna = codigoIdentificacionInterna;
        this.titulo = titulo;
        this.estado = estado;
        this.usuarioId = usuarioId;
        this.editorial = editorial;
        this.unidadesDisponibles = unidadesDisponibles;
        this.numeroDePaginas = numeroDePaginas;
        this.isbn = isbn;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

  

    public LibroModel() {
    }

    public String getCodigoIdentificacionInterna() {
        return codigoIdentificacionInterna;
    }

    public void setCodigoIdentificacionInterna(String codigoIdentificacionInterna) {
        this.codigoIdentificacionInterna = codigoIdentificacionInterna;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getUnidadesDisponibles() {
        return unidadesDisponibles;
    }

    public void setUnidadesDisponibles(int unidadesDisponibles) {
        this.unidadesDisponibles = unidadesDisponibles;
    }

    public int getNumeroDePaginas() {
        return numeroDePaginas;
    }

    public void setNumeroDePaginas(int numeroDePaginas) {
        this.numeroDePaginas = numeroDePaginas;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }
    
}
