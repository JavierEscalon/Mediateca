/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca.controladores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import mediateca.modelos.LibroModel;
import mediateca.modelos.UsuarioModel;

/**
 *
 * @author HP
 */
public class DaoLibro {

    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    public List Listar() {
        List<LibroModel> lista = new ArrayList<>();

        try {
            String sql = "select * from libro";
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sql);

            rs = stmt.executeQuery();
            while (rs.next()) {
                LibroModel l = new LibroModel();
                l.setCodigoIdentificacionInterna(rs.getString(1));
                l.setTitulo(rs.getString(2));
                l.setEditorial(rs.getString(5));
                l.setUnidadesDisponibles(rs.getInt(6));
                l.setAutor(rs.getString(7));
                l.setNumeroDePaginas(rs.getInt(8));
                l.setIsbn(rs.getString(9));
                l.setAnioPublicacion(rs.getInt(10));
                lista.add(l);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        };
        return lista;
    }

    public boolean insertar(LibroModel libro) {
        int r = 0;
        try {
            UsuarioModel usuario = Sesion.getUsuarioActual();
            int usuarioId = usuario.getId();
            System.out.println("id" + usuarioId);
            String sql = "insert into libro (codigo_identificacion_interna,titulo,usuario_id,editorial,unidades_disponibles,autor,numero_de_paginas,isbn,anio_publicacion)"
                    + "values (?,?,?,?,?,?,?,?,?)";
            String nuevoCodigo = generarCodigoIdentificacion();
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nuevoCodigo);
            stmt.setString(2, libro.getTitulo());
            stmt.setInt(3, usuarioId);
            stmt.setString(4, libro.getEditorial());
            stmt.setInt(5, libro.getUnidadesDisponibles());
            stmt.setString(6, libro.getAutor());
            stmt.setInt(7, libro.getNumeroDePaginas());
            stmt.setString(8, libro.getIsbn());
            stmt.setInt(9, libro.getAnioPublicacion());

            r = stmt.executeUpdate();
           
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        };
        if (r != 0) {
            return true;
        }
        return false;
    }

    public String generarCodigoIdentificacion() {
        String nuevoCodigo = "LIB00001"; // Código por defecto
        try {
            conn = Conexion.getConnection();
            String sql = "SELECT codigo_identificacion_interna FROM libro ORDER BY codigo_identificacion_interna DESC LIMIT 1";
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            if (rs.next()) {
                // Extraer el número del último código y sumarle uno
                String ultimoCodigo = rs.getString("codigo_identificacion_interna");
                int numero = Integer.parseInt(ultimoCodigo.substring(3)) + 1;
                nuevoCodigo = String.format("LIB%05d", numero); // Formato con 5 dígitos
            }
        
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return nuevoCodigo;
    }

    public boolean editar(LibroModel libro) {
        int r = 0;
        try {

            String sql = "update libro set titulo = ? ,editorial = ?,unidades_disponibles = ?,autor = ?,numero_de_paginas = ?,isbn = ?,anio_publicacion = ? where codigo_identificacion_interna = ?";

            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sql);

            stmt.setString(1, libro.getTitulo());
            stmt.setString(2, libro.getEditorial());
            stmt.setInt(3, libro.getUnidadesDisponibles());
            stmt.setString(4, libro.getAutor());
            stmt.setInt(5, libro.getNumeroDePaginas());
            stmt.setString(6, libro.getIsbn());
            stmt.setInt(7, libro.getAnioPublicacion());
            stmt.setString(8, libro.getCodigoIdentificacionInterna());
            r = stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        };
        if (r != 0) {
            return true;
        }
        return false;
    }

    public void buscar(LibroModel libro) {

        try {

            String sql = "select * from libro where codigo_identificacion_interna = ?";

            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, libro.getCodigoIdentificacionInterna());
            rs = stmt.executeQuery();
            if (rs.next()) {
                libro.setCodigoIdentificacionInterna(rs.getString(1));
                libro.setTitulo(rs.getString(2));
                libro.setEditorial(rs.getString(5));
                libro.setUnidadesDisponibles(rs.getInt(6));
                libro.setAutor(rs.getString(7));
                libro.setNumeroDePaginas(rs.getInt(8));
                libro.setIsbn(rs.getString(9));
                libro.setAnioPublicacion(rs.getInt(10));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        };

    }

    public boolean eliminar(LibroModel libro) {
        int r = 0;
        try {

            String sql = "delete from libro where codigo_identificacion_interna = ?";

            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, libro.getCodigoIdentificacionInterna());
            r = stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        };
        if (r != 0) {
            return true;
        }
        return false;
    }
}
