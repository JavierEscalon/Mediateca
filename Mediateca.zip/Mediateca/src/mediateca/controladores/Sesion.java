/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca.controladores;

import mediateca.modelos.UsuarioModel;

/**
 *
 * @author HP
 */
public class Sesion {
       private static UsuarioModel usuarioActual;

    public static UsuarioModel getUsuarioActual() {
        return usuarioActual;
    }

    public static void setUsuarioActual(UsuarioModel usuario) {
        usuarioActual = usuario;
    }
}
