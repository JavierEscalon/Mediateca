/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca.controladores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import mediateca.modelos.UsuarioModel;
import java.sql.SQLException;
import mediateca.modelos.MaterialModel;

/**
 *
 * @author HP
 */
public class DaoMateriales {

    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    public String generarCodigoIdentificacion(String tipo) {
        String nuevoCodigo = "LIB00001"; // Código por defecto
        String prefix = "LIB";
        try {
            conn = Conexion.getConnection();
            if (tipo.equals("Libro")) {
                nuevoCodigo = "LIB00001";
                prefix = "LIB";
            } else if (tipo.equals("Revista")) {
                nuevoCodigo = "REV00001";
                prefix = "REV";
            } else if (tipo.equals("CDA")) {
                nuevoCodigo = "CDA00001";
                prefix = "CDA";
            } else if (tipo.equals("DVD")) {
                nuevoCodigo = "DVD00001";
                prefix = "DVD";
            }

            // Filtrar por el tipo usando el prefijo correspondiente
            String sql = "SELECT codigo_identificacion_interna FROM material WHERE codigo_identificacion_interna LIKE ? ORDER BY codigo_identificacion_interna DESC LIMIT 1";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, prefix + "%");
            rs = stmt.executeQuery();

            if (rs.next()) {
                // Extraer el número del último código y sumarle uno
                String ultimoCodigo = rs.getString("codigo_identificacion_interna");
                int numero = Integer.parseInt(ultimoCodigo.substring(3)) + 1;
                nuevoCodigo = String.format(prefix + "%05d", numero); // Formato con 5 dígitos
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return nuevoCodigo;
    }

    public boolean insertar(MaterialModel material) {
        int r = 0;
        try {
            UsuarioModel usuario = Sesion.getUsuarioActual();
            int usuarioId = usuario.getId();
            String nuevoCodigo = generarCodigoIdentificacion(material.getTipo());

            // Inserción en la tabla 'material'
            String sqlMaterial = "INSERT INTO material (codigo_identificacion_interna, titulo, usuario_id) VALUES (?, ?, ?)";
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sqlMaterial);
            stmt.setString(1, nuevoCodigo);
            stmt.setString(2, material.getTitulo());
            stmt.setInt(3, usuarioId);
            r = stmt.executeUpdate();

            if (r == 0) {
                return false; // Si falla la inserción en 'material', termina aquí
            }
            // Inserción en la tabla 'material_escrito' si es un libro o revista

            if (material.getTipo().equals("Libro") || material.getTipo().equals("Revista")) {
                String sqlMaterialEscrito = "INSERT INTO material_escrito (codigo_identificacion_interna, editorial, unidades_disponibles) VALUES (?, ?, ?)";
                PreparedStatement stmtMaterialEscrito = conn.prepareStatement(sqlMaterialEscrito);
                stmtMaterialEscrito.setString(1, nuevoCodigo);
                stmtMaterialEscrito.setString(2, material.getEditorial());
                stmtMaterialEscrito.setInt(3, material.getUnidadesDisponibles());
                r = stmtMaterialEscrito.executeUpdate();

                if (r == 0) {
                    return false; // Si falla la inserción en 'material_escrito', termina aquí
                }
            } else {
                String sqlMaterialEscrito = "INSERT INTO material_audiovisual (codigo_identificacion_interna, genero, duracion) VALUES (?, ?, ?)";
                PreparedStatement stmtMaterialEscrito = conn.prepareStatement(sqlMaterialEscrito);
                stmtMaterialEscrito.setString(1, nuevoCodigo);
                stmtMaterialEscrito.setString(2, material.getGenero());
                stmtMaterialEscrito.setString(3, material.getDuracion());
                r = stmtMaterialEscrito.executeUpdate();

                if (r == 0) {
                    return false; // Si falla la inserción en 'material_escrito', termina aquí
                }
            }
            // Inserción en la tabla específica según el tipo de material
            String sqlEspecifico = "";
            PreparedStatement stmtEspecifico;

            switch (material.getTipo()) {
                case "Libro":
                    sqlEspecifico = "INSERT INTO libro (codigo_identificacion_interna, autor, numero_de_paginas, isbn, anio_publicacion) VALUES (?, ?, ?, ?, ?)";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, nuevoCodigo);
                    stmtEspecifico.setString(2, material.getAutor());
                    stmtEspecifico.setInt(3, material.getNumeroDePaginas());
                    stmtEspecifico.setString(4, material.getIsbn());
                    stmtEspecifico.setInt(5, material.getAnioPublicacion());
                    break;

                case "Revista":
                    sqlEspecifico = "INSERT INTO revista (codigo_identificacion_interna, fecha_publicacion, periodicidad) VALUES (?, ?, ?)";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, nuevoCodigo);
                    stmtEspecifico.setString(2, material.getFechaPublicacion());
                    stmtEspecifico.setString(3, material.getPeriodicidad());
                    break;

                case "CDA":
                    sqlEspecifico = "INSERT INTO cd (codigo_identificacion_interna, artista, numero_canciones, unidades_disponibles) VALUES (?, ?, ?, ?)";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, nuevoCodigo);
                    stmtEspecifico.setString(2, material.getArtista());
                    stmtEspecifico.setInt(3, material.getNumeroCanciones());
                    stmtEspecifico.setInt(4, material.getUnidadesDisponibles());
                    break;

                case "DVD":
                    sqlEspecifico = "INSERT INTO dvd (codigo_identificacion_interna, director) VALUES (?, ?)";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, nuevoCodigo);
                    stmtEspecifico.setString(2, material.getDirector());
                    break;

                default:
                    throw new IllegalArgumentException("Tipo de material no válido");
            }

            // Ejecutar la inserción en la tabla específica
            r = stmtEspecifico.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return r != 0;
    }

    public List<MaterialModel> Listar() {
        List<MaterialModel> lista = new ArrayList<>();

        try {
            // SQL para hacer JOIN en las tablas correspondientes según el tipo de material
            String sql = "SELECT m.codigo_identificacion_interna, m.titulo, m.estado, m.usuario_id, "
                    + "me.editorial, me.unidades_disponibles, "
                    + "l.autor, l.numero_de_paginas, l.isbn, l.anio_publicacion, "
                    + "r.fecha_publicacion, r.periodicidad, "
                    + "ma.genero, ma.duracion, "
                    + "cd.artista, cd.numero_canciones, cd.unidades_disponibles AS unidades_cd, "
                    + "dvd.director "
                    + "FROM material m "
                    + "LEFT JOIN material_escrito me ON m.codigo_identificacion_interna = me.codigo_identificacion_interna "
                    + "LEFT JOIN libro l ON me.codigo_identificacion_interna = l.codigo_identificacion_interna "
                    + "LEFT JOIN revista r ON me.codigo_identificacion_interna = r.codigo_identificacion_interna "
                    + "LEFT JOIN material_audiovisual ma ON m.codigo_identificacion_interna = ma.codigo_identificacion_interna "
                    + "LEFT JOIN cd ON ma.codigo_identificacion_interna = cd.codigo_identificacion_interna "
                    + "LEFT JOIN dvd ON ma.codigo_identificacion_interna = dvd.codigo_identificacion_interna";

            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sql);

            rs = stmt.executeQuery();
            while (rs.next()) {
                MaterialModel material = new MaterialModel();
                material.setCodigoIdentificacionInterna(rs.getString("codigo_identificacion_interna"));
                material.setTitulo(rs.getString("titulo"));
                material.setEstado(rs.getBoolean("estado"));
                material.setUsuarioId(rs.getInt("usuario_id"));
                material.setEditorial(rs.getString("editorial"));
                // Asigna unidades_disponibles para material_escrito
                int unidadesEscritos = rs.getInt("unidades_disponibles");
                material.setUnidadesDisponibles(unidadesEscritos);

                // Solo asigna unidades_cd si tiene un valor válido
                int unidadesCD = rs.getInt("unidades_cd");
                if (unidadesCD > 0) {
                    material.setUnidadesDisponibles(unidadesCD);
                }
                material.setAutor(rs.getString("autor"));
                material.setNumeroDePaginas(rs.getInt("numero_de_paginas"));
                material.setIsbn(rs.getString("isbn"));
                material.setAnioPublicacion(rs.getInt("anio_publicacion"));
                material.setFechaPublicacion(rs.getString("fecha_publicacion"));
                material.setPeriodicidad(rs.getString("periodicidad"));
                material.setGenero(rs.getString("genero"));
                material.setDuracion(rs.getString("duracion"));
                material.setArtista(rs.getString("artista"));
                material.setNumeroCanciones(rs.getInt("numero_canciones"));

                material.setDirector(rs.getString("director"));

                lista.add(material);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return lista;
    }

    public boolean editar(MaterialModel material) {
        int r = 0;
        try {
            String codigoExistente = material.getCodigoIdentificacionInterna();

            // Actualización en la tabla 'material'
            String sqlMaterial = "UPDATE material SET titulo = ? WHERE codigo_identificacion_interna = ?";
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sqlMaterial);
            stmt.setString(1, material.getTitulo());
            stmt.setString(2, codigoExistente);
            r = stmt.executeUpdate();

            if (r == 0) {
                return false; // Si falla la actualización en 'material', termina aquí
            }

            // Actualización en las tablas específicas según el tipo de material
            if (material.getTipo().equals("Libro") || material.getTipo().equals("Revista")) {
                String sqlMaterialEscrito = "UPDATE material_escrito SET editorial = ?, unidades_disponibles = ? WHERE codigo_identificacion_interna = ?";
                PreparedStatement stmtMaterialEscrito = conn.prepareStatement(sqlMaterialEscrito);
                stmtMaterialEscrito.setString(1, material.getEditorial());
                stmtMaterialEscrito.setInt(2, material.getUnidadesDisponibles());
                stmtMaterialEscrito.setString(3, codigoExistente);
                r = stmtMaterialEscrito.executeUpdate();

            } else {
                String sqlMaterialEscrito = "UPDATE material_audiovisual SET genero = ?, duracion = ? WHERE codigo_identificacion_interna = ?";
                PreparedStatement stmtMaterialEscrito = conn.prepareStatement(sqlMaterialEscrito);
                stmtMaterialEscrito.setString(1, material.getGenero());
                stmtMaterialEscrito.setString(2, material.getDuracion());
                stmtMaterialEscrito.setString(3, codigoExistente);
                r = stmtMaterialEscrito.executeUpdate();
            }

            String sqlEspecifico = "";
            PreparedStatement stmtEspecifico;

            // Actualización en la tabla específica según el tipo de material
            switch (material.getTipo()) {
                case "Libro":
                    sqlEspecifico = "UPDATE libro SET autor = ?, numero_de_paginas = ?, isbn = ?, anio_publicacion = ? WHERE codigo_identificacion_interna = ?";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, material.getAutor());
                    stmtEspecifico.setInt(2, material.getNumeroDePaginas());
                    stmtEspecifico.setString(3, material.getIsbn());
                    stmtEspecifico.setInt(4, material.getAnioPublicacion());
                    stmtEspecifico.setString(5, codigoExistente);
                    break;

                case "Revista":
                    sqlEspecifico = "UPDATE revista SET fecha_publicacion = ?, periodicidad = ? WHERE codigo_identificacion_interna = ?";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, material.getFechaPublicacion());
                    stmtEspecifico.setString(2, material.getPeriodicidad());
                    stmtEspecifico.setString(3, codigoExistente);
                    break;

                case "CDA":
                    sqlEspecifico = "UPDATE cd SET artista = ?, numero_canciones = ?, unidades_disponibles = ? WHERE codigo_identificacion_interna = ?";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, material.getArtista());
                    stmtEspecifico.setInt(2, material.getNumeroCanciones());
                    stmtEspecifico.setInt(3, material.getUnidadesDisponibles());
                    stmtEspecifico.setString(4, codigoExistente);
                    break;

                case "DVD":
                    sqlEspecifico = "UPDATE dvd SET director = ? WHERE codigo_identificacion_interna = ?";
                    stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                    stmtEspecifico.setString(1, material.getDirector());
                    stmtEspecifico.setString(2, codigoExistente);
                    break;

                default:
                    throw new IllegalArgumentException("Tipo de material no válido");
            }

            // Ejecutar la actualización en la tabla específica
            r = stmtEspecifico.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return r != 0;
    }





    /**
    * Eliminar un material o marcarlo como inactivo.
    * @param codigoIdentificacionInterna El código del material a eliminar o marcar como inactivo.
    * @param eliminarCompleto Si es true, elimina el registro por completo; si es false, lo marca como inactivo.
    * @return true si la operación fue exitosa, false en caso contrario.
    */

    public boolean eliminarMaterial(String codigoIdentificacionInterna, boolean eliminarCompleto) {
        int r = 0;
        try {
            conn = Conexion.getConnection();

            if (eliminarCompleto) {
                // Eliminar el material por completo, asegurándonos de eliminar primero de las tablas relacionadas
                String sqlEspecifico = "";
                PreparedStatement stmtEspecifico;

                // Eliminar de tablas específicas según el tipo de material
                // Intentar eliminar de cada tabla en cascada
                sqlEspecifico = "DELETE FROM libro WHERE codigo_identificacion_interna = ?";
                stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                stmtEspecifico.setString(1, codigoIdentificacionInterna);
                stmtEspecifico.executeUpdate();

                sqlEspecifico = "DELETE FROM revista WHERE codigo_identificacion_interna = ?";
                stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                stmtEspecifico.setString(1, codigoIdentificacionInterna);
                stmtEspecifico.executeUpdate();

                sqlEspecifico = "DELETE FROM cd WHERE codigo_identificacion_interna = ?";
                stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                stmtEspecifico.setString(1, codigoIdentificacionInterna);
                stmtEspecifico.executeUpdate();

                sqlEspecifico = "DELETE FROM dvd WHERE codigo_identificacion_interna = ?";
                stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                stmtEspecifico.setString(1, codigoIdentificacionInterna);
                stmtEspecifico.executeUpdate();

                // Eliminar de material_escrito y material_audiovisual
                sqlEspecifico = "DELETE FROM material_escrito WHERE codigo_identificacion_interna = ?";
                stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                stmtEspecifico.setString(1, codigoIdentificacionInterna);
                stmtEspecifico.executeUpdate();

                sqlEspecifico = "DELETE FROM material_audiovisual WHERE codigo_identificacion_interna = ?";
                stmtEspecifico = conn.prepareStatement(sqlEspecifico);
                stmtEspecifico.setString(1, codigoIdentificacionInterna);
                stmtEspecifico.executeUpdate();

                // Eliminar de la tabla principal 'material'
                String sqlMaterial = "DELETE FROM material WHERE codigo_identificacion_interna = ?";
                stmt = conn.prepareStatement(sqlMaterial);
                stmt.setString(1, codigoIdentificacionInterna);
                r = stmt.executeUpdate();
            } else {
                // Marcar como inactivo (cambiar el estado a false)
                String sqlMaterial = "UPDATE material SET estado = false WHERE codigo_identificacion_interna = ?";
                stmt = conn.prepareStatement(sqlMaterial);
                stmt.setString(1, codigoIdentificacionInterna);
                r = stmt.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }

        return r != 0;
    }




}
