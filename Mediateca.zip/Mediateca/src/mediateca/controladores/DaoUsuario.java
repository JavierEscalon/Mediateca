/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediateca.controladores;

import mediateca.modelos.UsuarioModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 *
 * @author HP
 */
public class DaoUsuario {
   
    public UsuarioModel login(String correo, String password) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;	
     
        UsuarioModel us = new UsuarioModel();
        String sql = "select * from usuario where correo='"+correo+"' and password='"+password+"'";
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(sql);
           
            rs = stmt.executeQuery();
            while (rs.next()) {
                us.setId(rs.getInt(1));
                us.setRol_id(rs.getInt(2));
                us.setNombre(rs.getString(3));
                us.setApellido(rs.getString(4));
                us.setCorreo(rs.getString(5));
                us.setPassword(rs.getString(6));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        };
        return us;
    }

}
